package com.bruce.assignmentweek7.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bruce.assignmentweek7.model.Album
import com.bruce.assignmentweek7.model.Artist
import com.bruce.assignmentweek7.model.Track
import com.bruce.assignmentweek7.repository.MusicRepository
import kotlinx.coroutines.launch
import retrofit2.HttpException

class MusicViewModel : ViewModel() {
    private val repository = MusicRepository()

    var searchText by mutableStateOf("Coldplay")
    var artist by mutableStateOf<Artist?>(null)
    var albums by mutableStateOf<List<Album>>(emptyList())
    var isArtistLoading by mutableStateOf(false)
    var artistError by mutableStateOf<String?>(null)

    var albumDetail by mutableStateOf<Album?>(null)
    var tracks by mutableStateOf<List<Track>>(emptyList())
    var isAlbumLoading by mutableStateOf(false)
    var albumError by mutableStateOf<String?>(null)
    private var lastAlbumId = ""

    init {
        searchArtist()
    }

    fun searchArtist() {
        val keyword = searchText.trim()
        if (keyword.isEmpty()) {
            return
        }
        viewModelScope.launch {
            isArtistLoading = true
            artistError = null
            try {
                val foundArtist = repository.getArtist(keyword)
                if (foundArtist == null) {
                    artist = null
                    albums = emptyList()
                    artistError = "Artis \"$keyword\" tidak ditemukan"
                } else {
                    artist = foundArtist
                    albums = repository.getAlbums(foundArtist.strArtist ?: keyword)
                }
            } catch (e: HttpException) {
                artist = null
                albums = emptyList()
                artistError = "Server error (HTTP ${e.code()})"
            } catch (e: Exception) {
                artist = null
                albums = emptyList()
                artistError = e.message ?: "Koneksi gagal, coba lagi"
            }
            isArtistLoading = false
        }
    }

    fun loadAlbumDetail(albumId: String) {
        lastAlbumId = albumId
        viewModelScope.launch {
            isAlbumLoading = true
            albumError = null
            albumDetail = null
            tracks = emptyList()
            try {
                val foundAlbum = repository.getAlbumDetail(albumId)
                if (foundAlbum == null) {
                    albumError = "Detail album tidak ditemukan"
                } else {
                    albumDetail = foundAlbum
                    tracks = repository.getTracks(albumId)
                }
            } catch (e: HttpException) {
                albumError = "Server error (HTTP ${e.code()})"
            } catch (e: Exception) {
                albumError = e.message ?: "Koneksi gagal, coba lagi"
            }
            isAlbumLoading = false
        }
    }

    fun retryAlbumDetail() {
        loadAlbumDetail(lastAlbumId)
    }
}

package com.bruce.assignmentweek7.repository

import com.bruce.assignmentweek7.model.PokemonCard
import com.bruce.assignmentweek7.service.PokemonApi

class PokemonRepository {
    suspend fun searchCards(pokemonName: String): List<PokemonCard> {
        val response = PokemonApi.service.searchCards(
            authorization = "Bearer ${PokemonApi.API_KEY}",
            search = pokemonName,
            limit = 20
        )
        return response.data ?: emptyList()
    }
}

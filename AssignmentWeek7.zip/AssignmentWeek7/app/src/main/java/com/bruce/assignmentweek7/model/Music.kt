package com.bruce.assignmentweek7.model

data class ArtistResponse(
    val artists: List<Artist>?
)

data class Artist(
    val idArtist: String?,
    val strArtist: String?,
    val strGenre: String?,
    val strStyle: String?,
    val strCountry: String?,
    val strBiographyEN: String?,
    val strArtistThumb: String?,
    val strArtistBanner: String?,
    val strArtistFanart: String?
)

data class AlbumResponse(
    val album: List<Album>?
)

data class Album(
    val idAlbum: String?,
    val strAlbum: String?,
    val strArtist: String?,
    val intYearReleased: String?,
    val strGenre: String?,
    val strStyle: String?,
    val strAlbumThumb: String?,
    val strDescriptionEN: String?
)

data class TrackResponse(
    val track: List<Track>?
)

data class Track(
    val idTrack: String?,
    val strTrack: String?,
    val strGenre: String?,
    val intDuration: String?,
    val intTrackNumber: String?
)

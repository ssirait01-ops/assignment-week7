package com.bruce.assignmentweek7.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bruce.assignmentweek7.model.PokemonCard
import com.bruce.assignmentweek7.repository.PokemonRepository
import kotlinx.coroutines.launch
import retrofit2.HttpException

class PokemonViewModel : ViewModel() {
    private val repository = PokemonRepository()

    var searchText by mutableStateOf("Charizard")
    var cards by mutableStateOf<List<PokemonCard>>(emptyList())
    var isLoading by mutableStateOf(false)
    var errorTitle by mutableStateOf("")
    var errorMessage by mutableStateOf<String?>(null)

    init {
        searchCards()
    }

    fun searchCards() {
        val keyword = searchText.trim()
        if (keyword.isEmpty()) {
            return
        }
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            try {
                cards = repository.searchCards(keyword)
                if (cards.isEmpty()) {
                    errorTitle = "Card Not Found"
                    errorMessage = "Tidak ada card dengan nama \"$keyword\""
                }
            } catch (e: HttpException) {
                cards = emptyList()
                errorTitle = "Connection Failed"
                errorMessage = "HTTP ${e.code()}"
            } catch (e: Exception) {
                cards = emptyList()
                errorTitle = "Connection Failed"
                errorMessage = e.message ?: "Tidak dapat terhubung ke server"
            }
            isLoading = false
        }
    }
}

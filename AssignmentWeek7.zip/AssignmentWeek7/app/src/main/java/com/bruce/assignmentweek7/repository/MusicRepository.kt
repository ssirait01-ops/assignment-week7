package com.bruce.assignmentweek7.repository

import com.bruce.assignmentweek7.model.Album
import com.bruce.assignmentweek7.model.Artist
import com.bruce.assignmentweek7.model.Track
import com.bruce.assignmentweek7.service.AudioDbApi

class MusicRepository {
    suspend fun getArtist(artistName: String): Artist? {
        return AudioDbApi.service.searchArtist(artistName).artists?.firstOrNull()
    }

    suspend fun getAlbums(artistName: String): List<Album> {
        return AudioDbApi.service.searchAlbum(artistName).album ?: emptyList()
    }

    suspend fun getAlbumDetail(albumId: String): Album? {
        return AudioDbApi.service.getAlbumDetail(albumId).album?.firstOrNull()
    }

    suspend fun getTracks(albumId: String): List<Track> {
        val tracks = AudioDbApi.service.getTracks(albumId).track ?: emptyList()
        return tracks.sortedBy { it.intTrackNumber?.toIntOrNull() ?: 0 }
    }
}

package com.bruce.assignmentweek7.service

import com.bruce.assignmentweek7.model.PokemonCardResponse
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface PokemonService {
    @GET("cards")
    suspend fun searchCards(
        @Header("Authorization") authorization: String,
        @Query("search") search: String,
        @Query("limit") limit: Int
    ): PokemonCardResponse
}

object PokemonApi {
    const val API_KEY = "PASTE_API_KEY_KAMU_DI_SINI"

    val service: PokemonService = Retrofit.Builder()
        .baseUrl("https://www.pokemonpricetracker.com/api/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(PokemonService::class.java)
}

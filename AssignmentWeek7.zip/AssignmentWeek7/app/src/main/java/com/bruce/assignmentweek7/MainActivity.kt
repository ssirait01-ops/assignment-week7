package com.bruce.assignmentweek7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.bruce.assignmentweek7.ui.theme.AssignmentWeek7Theme
import com.bruce.assignmentweek7.view.Soal1View
import com.bruce.assignmentweek7.view.Soal2View

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val nomorSoal = 1
        setContent {
            AssignmentWeek7Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Black
                ) { innerPadding ->
                    when (nomorSoal) {
                        1 -> Soal1View(innerPadding = innerPadding)
                        2 -> Soal2View(innerPadding = innerPadding)
                    }
                }
            }
        }
    }
}

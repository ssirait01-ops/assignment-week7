package com.bruce.assignmentweek7.model

data class PokemonCardResponse(
    val data: List<PokemonCard>?
)

data class PokemonCard(
    val tcgPlayerId: String?,
    val name: String?,
    val setName: String?,
    val cardNumber: String?,
    val rarity: String?,
    val cardType: String?,
    val hp: String?,
    val artist: String?,
    val imageCdnUrl: String?,
    val imageCdnUrl400: String?,
    val imageCdnUrl800: String?,
    val prices: PokemonPrice?
)

data class PokemonPrice(
    val market: Double?,
    val low: Double?,
    val sellers: Int?,
    val listings: Int?,
    val primaryPrinting: String?
)

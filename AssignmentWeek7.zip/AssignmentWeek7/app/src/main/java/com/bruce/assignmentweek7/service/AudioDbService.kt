package com.bruce.assignmentweek7.service

import com.bruce.assignmentweek7.model.AlbumResponse
import com.bruce.assignmentweek7.model.ArtistResponse
import com.bruce.assignmentweek7.model.TrackResponse
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface AudioDbService {
    @GET("search.php")
    suspend fun searchArtist(@Query("s") artistName: String): ArtistResponse

    @GET("searchalbum.php")
    suspend fun searchAlbum(@Query("s") artistName: String): AlbumResponse

    @GET("album.php")
    suspend fun getAlbumDetail(@Query("m") albumId: String): AlbumResponse

    @GET("track.php")
    suspend fun getTracks(@Query("m") albumId: String): TrackResponse
}

object AudioDbApi {
    val service: AudioDbService = Retrofit.Builder()
        .baseUrl("https://www.theaudiodb.com/api/v1/json/123/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(AudioDbService::class.java)
}
